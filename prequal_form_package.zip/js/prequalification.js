document.addEventListener('DOMContentLoaded', function () {
  console.log("JS loaded");
});
